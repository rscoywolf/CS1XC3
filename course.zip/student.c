/**
 * @file student.c
 * @author Ryan Spurgeon
 * @brief a module of functions for student management
 * @version 0.1
 * @date 2022-04-11
 *
 * @copyright Copyright (c) 2022
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"

/**
 * @brief add a grade to a student's profile
 *
 * @param student : the student
 * @param grade : the grade to be added
 */
void add_grade(Student *student, double grade)
{
  // Increment the total student counter of the course by 1
  student->num_grades++;
  // If the newly enrolled student is the only one in the course
  if (student->num_grades == 1)
    // Initialize an array to 0s using calloc
    student->grades = calloc(1, sizeof(double));
  // Otherwise
  else
  {
    // Resize the existing array using realloc to be able to fit the new grade
    student->grades =
        realloc(student->grades, sizeof(double) * student->num_grades);
  }
  // Add the new grade to the end of the array of grades
  student->grades[student->num_grades - 1] = grade;
}

/**
 * @brief get the GPA of a student
 *
 * @param student : the student
 * @return double : their GPA
 */
double average(Student *student)
{
  // base case
  if (student->num_grades == 0)
    return 0;

  // go through each grade and compute average of all grades
  double total = 0;
  for (int i = 0; i < student->num_grades; i++)
    total += student->grades[i];
  return total / ((double)student->num_grades);
}

/**
 * @brief print the details of a student
 *
 * @param student : the student
 */
void print_student(Student *student)
{
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");
  for (int i = 0; i < student->num_grades; i++)
    printf("%.2f ", student->grades[i]);
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}

/**
 * @brief generate a pointer to a randomly generated student
 *
 * @param grades : the number of grades to generate for the student
 * @return Student* : the randomly generated student's pointer
 */
Student *generate_random_student(int grades)
{
  char first_names[][24] =
      {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
       "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
       "Julie", "Omar", "Yousef", "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  char last_names[][24] =
      {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams",
       "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat",
       "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};

  // allocate enough space for one student
  Student *new_student = calloc(1, sizeof(Student));

  // pick first and last name
  strcpy(new_student->first_name, first_names[rand() % 24]);
  strcpy(new_student->last_name, last_names[rand() % 24]);

  // generate random student id
  for (int i = 0; i < 10; i++)
    new_student->id[i] = (char)((rand() % 10) + 48);
  new_student->id[10] = '\0';

  // generate random grades
  for (int i = 0; i < grades; i++)
  {
    add_grade(new_student, (double)(25 + (rand() % 75)));
  }

  return new_student;
}