/**
 * @file course.c
 * @author Ryan Spurgeon
 * @brief module for managing courses
 * @version 0.1
 * @date 2022-04-11
 *
 * @copyright Copyright (c) 2022
 *
 */

#include "course.h"
#include <stdlib.h>
#include <stdio.h>

/**
 * @brief add a student to a course
 *
 * @param course : the course for the student to be added to
 * @param student : the student to be added
 */
void enroll_student(Course *course, Student *student)
{
  // Increment the total student counter of the course by 1
  course->total_students++;
  // If the newly enrolled student is the only one in the course
  if (course->total_students == 1)
  {
    // Initialize an array of size 1 Student to 0s using calloc
    course->students = calloc(1, sizeof(Student));
  }
  // Otherwise
  else
  {
    // Resize the existing array using realloc to be able to fit the new student
    course->students =
        realloc(course->students, course->total_students * sizeof(Student));
  }
  // Add the new student to the end of the array of students
  course->students[course->total_students - 1] = *student;
}

/**
 * @brief prints all the info for a course
 *
 * @param course : the course to have its info printed
 */
void print_course(Course *course)
{
  // print the name, code, total students, and each student's info
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++)
    print_student(&course->students[i]);
}

/**
 * @brief find the top student in the given course
 *
 * @param course : the course to search for the top student
 * @return Student* : pointer to the top student in the course
 */
Student *top_student(Course *course)
{
  if (course->total_students == 0)
    return NULL;

  // set up some variables to use while searching the course
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];

  // loop through the students and find the one with the best GPA
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average)
    {
      max_average = student_average;
      student = &course->students[i];
    }
  }

  return student;
}

/**
 * @brief find all the students in a course that are passing
 *
 * @param course : the course to search for passing students
 * @param total_passing : the total number of students passing
 * @return Student* : array of students that are passing the course
 */
Student *passing(Course *course, int *total_passing)
{
  // some variables to use
  int count = 0;
  Student *passing = NULL;

  // count every student that is passing using counter
  for (int i = 0; i < course->total_students; i++)
    if (average(&course->students[i]) >= 50)
      count++;

  // create array to be used to store passing students initialized to 0s (calloc)
  passing = calloc(count, sizeof(Student));

  // go through each student and store their pointer in `passing` if they are passing
  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++;
    }
  }

  *total_passing = count;

  return passing;
}