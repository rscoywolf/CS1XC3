/**
 * @file course.h
 * @author Ryan Spurgeon
 * @brief header for course.c
 * @version 0.1
 * @date 2022-04-11
 *
 * @copyright Copyright (c) 2022
 *
 */

#include "student.h"
#include <stdbool.h>

/**
 * @brief Defines the data struct used to represent the details of a single course
 */
typedef struct _course
{
  char name[100];     /**< The name of the course */
  char code[10];      /**< The course code */
  Student *students;  /**< An array of students enrolled in the course */
  int total_students; /**< An integer representing the total number of students enrolled */
} Course;

/**
 * @brief add a student to a course
 *
 * @param course : the course for the student to be added to
 * @param student : the student to be added
 */
void enroll_student(Course *course, Student *student);

/**
 * @brief prints all the info for a course
 *
 * @param course : the course to have its info printed
 */
void print_course(Course *course);

/**
 * @brief find the top student in the given course
 *
 * @param course : the course to search for the top student
 * @return Student* : pointer to the top student in the course
 */
Student *top_student(Course *course);

/**
 * @brief find all the students in a course that are passing
 *
 * @param course : the course to search for passing students
 * @param total_passing : the total number of students passing
 * @return Student* : array of students that are passing the course
 */
Student *passing(Course *course, int *total_passing);
