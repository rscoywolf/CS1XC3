/**
 * @mainpage This is where your mainpage text would go
 * @file main.c
 * @author Ryan Spurgeon
 * @brief main file for school software package
 * @version 0.1
 * @date 2022-04-11
 *
 * @copyright Copyright (c) 2022
 *
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

/**
 * @brief main
 *
 * @return int : exit code
 */
int main()
{
  // Generates a random number using the time as a seed
  srand((unsigned)time(NULL));
  // Creates a new `Course` array struct of size 1 Course initiated with 0s (calloc) called MATH101
  Course *MATH101 = calloc(1, sizeof(Course));
  // Sets the name of MATH101 to "Basics of Mathematics"
  strcpy(MATH101->name, "Basics of Mathematics");
  // Sets the course code of MATH101 to "MATH 101"
  strcpy(MATH101->code, "MATH 101");

  // Enrolls 20 randomly-generated students using a for loop that calls the enroll_student function with arguments MATH101 as the course and generate_random_student with argument 8 grades to generate as the student
  for (int i = 0; i < 20; i++)
    enroll_student(MATH101, generate_random_student(8));

  // Pretty prints the details of the course MATH101
  print_course(MATH101);

  // Creates a new pointer of type `Student` called "student"
  Student *student;
  // Sets the `student` pointer to the address of the top student in MATH101 using the top_student function
  student = top_student(MATH101);
  // Pretty prints the details of the top student
  printf("\n\nTop student: \n\n");
  print_student(student);

  // Creates an integer to represent the total number of students passing the course
  int total_passing;
  // Creates a `Student` pointer that points to an array of all passing students in MATH101 generated using the `passing` function
  Student *passing_students = passing(MATH101, &total_passing);
  // Pretty print the number of students passing
  printf("\nTotal passing: %d\n", total_passing);
  // Print the details of each passing student
  printf("\nPassing students:\n\n");
  for (int i = 0; i < total_passing; i++)
    print_student(&passing_students[i]);

  // End the program
  return 0;
}