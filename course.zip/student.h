/**
 * @file student.h
 * @author Ryan Spurgeon
 * @brief the header for student.c
 * @version 0.1
 * @date 2022-04-11
 *
 * @copyright Copyright (c) 2022
 *
 */

/**
 * @brief data structure for a student
 *
 */
typedef struct _student
{
  char first_name[50]; /**< student first name */
  char last_name[50];  /**< student last name */
  char id[11];         /**< student id */
  double *grades;      /**< student grades */
  int num_grades;      /**< number of grades */
} Student;

/**
 * @brief add a grade to a student's profile
 *
 * @param student : the student
 * @param grade : the grade to be added
 */
void add_grade(Student *student, double grade);

/**
 * @brief get the GPA of a student
 *
 * @param student : the student
 * @return double : their GPA
 */
double average(Student *student);

/**
 * @brief print the details of a student
 *
 * @param student : the student
 */
void print_student(Student *student);

/**
 * @brief generate a pointer to a randomly generated student
 *
 * @param grades : the number of grades to generate for the student
 * @return Student* : the randomly generated student's pointer
 */
Student *generate_random_student(int grades);
